#ifndef API_FAN_H
#define API_FAN_H

#include <stdint.h>

#define FAN_PWM_STOP   0
#define FAN_PWM_LOW    32
#define FAN_PWM_MID    60
#define FAN_PWM_HIGH   86
#define FAN_PWM_BOOST  97


/*����״̬�ṹ��ͱ�������*/
typedef enum{	
	STOP =0,
	LOW = 1,
	MID = 2,
	HIGH =3 ,
	BOOST=4,
	AI=5,
}Fan_Mode;

#define AFTER_BOOST_FAN_MODE LOW
#define DEFAULT_FAN_MODE LOW
typedef enum{
	FAN_OFF = 0,
	FAN_ON = 1,
}Fan_Onoff;

typedef struct{
	Fan_Onoff fan_onoff;
	Fan_Mode fan_mode;
	uint8_t fan_pwm;
}Fan_Status;

#define SetFanPWM(PWM_DUTY) TIM_SetCompare4(GENERAL_TIM, PWM_DUTY);

void InitFan(void);
Fan_Status * GetFanStatus(void);
Fan_Mode GetFanMode(void);
void SetFanMode(Fan_Mode fanMode);
void SetFan(Fan_Mode fanMode);
void SetFanPWMPara(uint8_t pwm);
void AdjFanPWM(uint8_t pwm);
void TurnOnFan(void);
void TurnOffFan(void);
void AdjFanRecurrently(void);


/*=================================��ѹ����=====================================================*/
#define REF_PWM_LOW   56
#define REF_PWM_HIGH  70
#define REF_PWM_14KV  83
#define REF_PWM_16KV5 76
#define VOLT_PWM_STOP  REF_PWM_14KV
#define VOLT_PWM_LOW   REF_PWM_16KV5
#define VOLT_PWM_MID   REF_PWM_16KV5
#define VOLT_PWM_HIGH  REF_PWM_16KV5
#define VOLT_PWM_BOOST REF_PWM_16KV5

uint8_t IsHighVoltOn(void);
uint8_t IsHighVoltStable(void);
void HIGH_VOLT_OFF(void);
void HIGH_VOLT_ON(void);
#define SetVoltPWM(PWM_DUTY) TIM_SetCompare3(GENERAL_TIM, PWM_DUTY);

#endif

