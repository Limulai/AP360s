#include "app_ap36xx.h"
#include "api_led.h"
#include "BSP_AP360_GPIO.h"
#include "BSP_TIMER.h"
#include "BSP_ADC.H"
#include "BSP_EEPROM.h"
//#include "BSP_HDC1080.h"
#include "BSP_CH2O_N_PM25.h"

#include "FreeRTOS.h"
#include "task.h"
#include "event_groups.h"
#include "semphr.h"

#include "sw_iic.h"
#include "filter.h"
#include <stdio.h>
//#include "gizwits_app.h"
//#include "gizwits_protocol.h"

#include "api_fan.h"

EventGroupHandle_t  key_event = NULL;
///*=================================KEY ���================================================================================*/

uint8_t key_state(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin){
	uint8_t key_value;
	key_value = GPIO_ReadInputDataBit(GPIOx, GPIO_Pin);
	return key_value;
}


KeyType key_nscan(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin, uint16_t *count, uint16_t count_max){
	unsigned char key_value;
	static KeyType key_state;
	key_value = GPIO_ReadInputDataBit(GPIOx, GPIO_Pin);
	
	if(1!=key_value){
		
		if (GetLightEnable() == 0) {
			SetLightEnable(1);
		}	
		
		(*count) ++;
		
		if(*count>=count_max){
			*count = 0;
			key_state = KEY_LONG_PRESS;
		}
		
	}
	else{
		key_state = KEY_IDLE;
		if(*count>=KEY_SHORT_TIME){
			key_state = KEY_SHORT_PRESS;	
		}
		*count=0;
	}
	return key_state;
}


/*
	rtos �� ����ɨ�����

*/
KeyType key_scan(GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin, uint16_t *count){
	unsigned char key_value;
	static KeyType key_state;

	key_value = GPIO_ReadInputDataBit(GPIOx, GPIO_Pin);
	if(1!=key_value){
		(*count) ++;
		key_state = KEY_IDLE;
	}
	else{
		if(*count>=MAX_PRESS_TIME){
			key_state = KEY_IDLE;
		}
		else if(*count>=KEY_10S_TIME){
			key_state = KEY_10S_PRESS;			
		}
		else if(*count>=KEY_2S_TIME){
			key_state = KEY_2S_PRESS;		
		}
		else if(*count>=KEY_SHORT_TIME){
			key_state = KEY_SHORT_PRESS;	
		}
		else{
			key_state = KEY_IDLE;
		}
		*count=0;

	}
	return key_state;
}




/*================================ADC Ӧ�ú���=========================================================================*/
uint8_t GetVoltTungsten_N_Adj(void){
//	static uint8_t times=0;
//	static uint16_t volt_array_a[5];
//	static uint16_t volt_array_b[5];
	float tungsten_a_volt;
	float tungsten_b_volt;
	uint8_t return_value=0;
	
	//if(!(g_SystemStatus == MODE_NORMAL && g_isHighVoltStable == HIGH_VOLT_STABLE)) return 0;//normal״̬�¸�ѹ����Ŵ򿪣��������������˿
	
	/*every 100 microseconds implement this code below*/

//		volt_array_a[times] = ADC_ConvertedValue[Tungsten_A_Subscript];
//		volt_array_b[times] = ADC_ConvertedValue[Tungsten_B_Subscript];

		tungsten_a_volt = (float)ADC_ConvertedValue[Tungsten_A_Subscript]/4096*3.3;
		tungsten_b_volt = (float)ADC_ConvertedValue[Tungsten_B_Subscript]/4096*3.3;
		if(tungsten_a_volt < TUNGSTEN_VOLT_LOWER_LIMIT  ){
			
			//g_SystemStatus = MODE_FAULT;
			return_value |= TUNGSTEN_A_BREAK;
		}
		if(tungsten_b_volt < TUNGSTEN_VOLT_LOWER_LIMIT ){
			
			//g_SystemStatus = MODE_FAULT;
			return_value |= TUNGSTEN_B_BREAK;
		}
		
	
	//g_tungsten_break = return_value;
	return return_value;
}

/*

*/
uint8_t GetVoltAlarm_N_Adj(void){
	float alarm_volt;
	/*every 20 microseconds implement this code below*/
	alarm_volt = (float)ADC_ConvertedValue[HighVolt_Alarm_Subscript]/4096*3.3;
	if (GetFanMode() == STOP) {
		if(alarm_volt>ALARM_VOLT_UPPER_LIMIT || alarm_volt<ALARM_VOLT_LOWER_LIMIT_FAN_LOW){
			//g_SystemStatus = MODE_FAULT;
			return ALARM_SEMAPHORE;
		}
	}
	else {
		if(alarm_volt>ALARM_VOLT_UPPER_LIMIT || alarm_volt<ALARM_VOLT_LOWER_LIMIT){
			//g_SystemStatus = MODE_FAULT;
			return ALARM_SEMAPHORE;
		}
	}
		
	return 0;
}


///*=================================������==============================================================================*/
float g_temperature=0;
float g_humidity=0;
float g_pm25=0;
float g_pm10=0;
float g_ch2o=0;
sensor_buff_t pm25_data = {0, 0};
sensor_buff_t ch2o_data = {0, 0};

void putin_sensor_buff(sensor_buff_t *sensor_buff, float data){
	*(sensor_buff->circular_buff + sensor_buff->circular_subscript) = data;
	sensor_buff->circular_subscript ++;
	if (sensor_buff->circular_subscript >= SENSOR_BUFF_DEPTH)
		sensor_buff->circular_subscript = 0;
}

/*
	�������룬����precisionλС��
	
*/
uint8_t my_round(float indata, uint8_t precision, float *outdata){
	uint32_t pre=1;
	uint8_t i;
	for (i=0; i<precision; i++){
		pre *= 10;
	}
	*outdata = (int)((indata*pre)+0.5)/(float)pre;
	
	return 0;
}

/*
	���ܣ� �˲�������ԭʼ��ֵ
Parameter: precision , ������Ҫ������С����λ��
		   buff ,  ����������ָ��

*/
float SensorDataFilter(float *buff, uint8_t precision){
	uint8_t rank[SENSOR_BUFF_DEPTH] = {0,1,2,3,4};//����������±�
	uint8_t j,k;
	uint8_t temp;
	float sum=0;
//	uint8_t i;
	// ð�����򣬸�������±갴С��������
	for (j=0; j<SENSOR_BUFF_DEPTH-1; j++){
		for (k=0; k<SENSOR_BUFF_DEPTH-j-1; k++){
			if (*(buff+rank[k]) > *(buff+rank[k+1])){
				temp = rank[k];
				rank[k] = rank[k+1];
				rank[k+1] = temp;
			}
		}
	}
	// ȥ�������Сֵ��ʣ��ȡ����ƽ��ֵ
	sum = *(buff+rank[1]) + *(buff+rank[2]) + *(buff+rank[3]);
	sum /= SENSOR_BUFF_DEPTH-2;
	// �������룬��������λ
	//sum = (int)(sum+0.5)/1.0;
	my_round(sum, precision, &sum);
	
	return sum;
}



float CalculateTemperature(uint16_t temperature_from_hdc1080){
	float temperature;
	temperature = (float)temperature_from_hdc1080 * 165 /65536 - 40;
	return temperature;
}

float CalculateHumidity(uint16_t humidity_from_hdc1080){
	float humidity;
	humidity = (float)humidity_from_hdc1080 /65536;
	return humidity;
}

//#define PRINT_TEMPERATURE_N_HUMIDITY
void GetTemperatureHumidity(float *temp_f, float *humi_f){
	uint16_t temp, humi;
		
	ReadHDC1080_sw_iic(&temp, &humi);
	*temp_f = CalculateTemperature(temp);
	*humi_f = CalculateHumidity(humi);

}




/*=================================����======================================================================*/
uint16_t g_clean_time_max=0;
uint16_t g_clean_time_resolution=0;
uint16_t g_boost_time_max=0;
uint16_t g_boost_time_resolution=0;
uint16_t g_drying_time_max=0;
uint16_t g_drying_time_resolution=0;
uint8_t g_ala_enable=1;
uint8_t g_tun_enable=1;

/**
* @brief ���Ź���ʼ���ӿ�

*Tout=((4��2^prer) ��rlr) /40 = ((4 * 2^4) * 625) / 40 = 1000ms = 1s

*prer Ϊ���Ź�ʱ��Ԥ��Ƶֵ��IWDG_PR ֵ������ΧΪ0~7

*rlr Ϊ���Ź�����װ��ֵ��IWDG_RLR ��ֵ��

*1s��ι��,���Ź��Ϳ��Բ���λ , ���Ź�ʱ�Ӳ���׼��40kHz

* @param timeoutS : ��λʱ�䣬��λ����
* @return none
*/

void watchdogInit(uint8_t timeoutS)//��
{

    uint8_t prer = 4;
    uint16_t rlr = timeoutS * 625;
    IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable); /* ʹ�ܶԼĴ���IWDG_PR��IWDG_RLR��д����*/
    IWDG_SetPrescaler(prer);    /*����IWDGԤ��Ƶֵ:����IWDGԤ��Ƶֵ*/
    IWDG_SetReload(rlr);     /*����IWDG��װ��ֵ*/
    IWDG_ReloadCounter();    /*����IWDG��װ�ؼĴ�����ֵ��װ��IWDG������*/
    IWDG_Enable();        /*ʹ��IWDG*/

}

/**
* @brief ���Ź�ι���ӿ�

* @param  none
* @return none
*/
void watchdogFeed(void)
{
    IWDG->KR=0xaaaa;
}



///*=================================ϵͳģʽ�ṹ��=======================================================================*/
MODE g_SystemStatus = MODE_POWEROFF;/*ϵͳģʽ�ṹ���ʼ��*/
malfunction_t g_malfunction = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
wifi_status_t g_wifi_status = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
uint8_t g_fault_code = 0;
uint8_t g_lock = 0;
uint8_t g_light_enable = 1;
uint8_t g_app_connected = 0;
//rt_thread_t cleanled_flashing_thread;
//rt_thread_t fault_general_flashing_thread;
//rt_thread_t fault_tungsten_flashing_thread;
//rt_thread_t fault_wifi_dis_flashing_thread;
//rt_thread_t pair_thread;
TaskHandle_t HandleCleanFlashing = NULL;
TaskHandle_t HandleFaultGeneralFlashing = NULL;
TaskHandle_t HandlePair = NULL;
TaskHandle_t HandleBoostFlashing = NULL;
TaskHandle_t HandleBoostCount = NULL;
TaskHandle_t HandleCountDrying = NULL;
uint8_t f_boost_created = 0;
uint8_t f_clean_created = 0;
uint8_t f_fault_created = 0;
uint8_t f_pair_created = 0;
uint8_t f_drying_count = 0;
uint8_t f_boost_count = 0;

TimerHandle_t sleep_tm = NULL;


void adj_malfunction(malfunction_t *malfunction){
	static malfunction_t last_malfunction = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	
	if(last_malfunction.alarm_highVolt != malfunction->alarm_highVolt){
	// high volt 
		if(malfunction->alarm_highVolt==1){
			malfunction->malfunction_code = 204;
		}
//		else{
//			malfunction->malfunction_code -= 4;
//		}
	}
	else if(last_malfunction.alarm_tungsten_a_broken != malfunction->alarm_tungsten_a_broken){
	//tungsten left
		if(malfunction->alarm_tungsten_a_broken==1){
			malfunction->malfunction_code = 201;
		}
//		else{
//			malfunction->malfunction_code -= 1;
//		}
	}
	else if(last_malfunction.alarm_tungsten_b_broken != malfunction->alarm_tungsten_b_broken){
	//tungsten right
		if(malfunction->alarm_tungsten_b_broken==1){
			malfunction->malfunction_code = 202;
		}
//		else{
//			malfunction->malfunction_code -= 2;
//		}
	}
	else if(last_malfunction.nodata_pm25_module != malfunction->nodata_pm25_module){
	//pm2.5 module
		if(malfunction->nodata_pm25_module==DISCONNECTED){
			malfunction->malfunction_code = 158;
		}
	}
	else if(last_malfunction.nodata_ch2o_module != malfunction->nodata_ch2o_module){
	//CH2O module
		if(malfunction->nodata_ch2o_module==DISCONNECTED){
			malfunction->malfunction_code = 128;
		}
	}
	else if(last_malfunction.nodata_hdc_module != malfunction->nodata_hdc_module){
	//HDC(humidity & temperature) module
		if(malfunction->nodata_hdc_module==DISCONNECTED){
			malfunction->malfunction_code = 148;
		}
	}
	else if(last_malfunction.nodata_eeprom_module != malfunction->nodata_eeprom_module){
	//eeprom module
		if(malfunction->nodata_eeprom_module==DISCONNECTED){
			//malfunction->malfunction_code += 2;
		}
	}
	else if(malfunction->alarm_highVolt==0 &&
			malfunction->alarm_tungsten_a_broken==0 &&
			malfunction->alarm_tungsten_b_broken==0 &&
			malfunction->nodata_pm25_module==0 &&
			malfunction->nodata_ch2o_module==0 &&
			malfunction->nodata_hdc_module==0 &&
			malfunction->nodata_eeprom_module==0 &&
			malfunction->fan==0 ){
				
		malfunction->malfunction_code = 0;
	}
	
	
	//
	last_malfunction.alarm_highVolt = malfunction->alarm_highVolt;
	last_malfunction.alarm_tungsten_a_broken = malfunction->alarm_tungsten_a_broken;
	last_malfunction.alarm_tungsten_b_broken = malfunction->alarm_tungsten_b_broken;
	last_malfunction.nodata_pm25_module = malfunction->nodata_pm25_module;
	last_malfunction.nodata_ch2o_module = malfunction->nodata_ch2o_module;
	last_malfunction.nodata_hdc_module = malfunction->nodata_hdc_module;
	last_malfunction.nodata_eeprom_module = malfunction->nodata_eeprom_module;
	last_malfunction.fan = malfunction->fan;
}

//#define INDICATROES_CYC_TIME (RT_TICK_PER_SECOND/50)
/*
	�ָ���������

*/
void SetSystemDefault(void)
{
	uint8_t i;
	uint8_t temp_array[2];
	g_SystemStatus = MODE_POWEROFF;
	vTaskDelay(configTICK_RATE_HZ/10);//��ʱ�Ǻ���
	/* ������ʱ���ۻ� */
	g_clean_time[CLEAN_TIME_HIGH] = 0;
	g_clean_time[CLEAN_TIME_LOW] = 0;
	I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);
	/* ���������ָ���Ĭ��ֵ */
	g_clean_time_max = CLEAN_TIME_MAX_DEFAULT;
	temp_array[0] = (uint8_t)(CLEAN_TIME_MAX_DEFAULT>>8);
	temp_array[1] = (uint8_t)(CLEAN_TIME_MAX_DEFAULT);
	I2C_EE_BufferWrite(temp_array, CLEAN_TIME_MAX_ADDR, 2);
	g_clean_time_resolution = CLEAN_TIME_RESOLUTION_DEFAULT;
	temp_array[0] = (uint8_t)(CLEAN_TIME_RESOLUTION_DEFAULT>>8);
	temp_array[1] = (uint8_t)(CLEAN_TIME_RESOLUTION_DEFAULT);
	I2C_EE_BufferWrite(temp_array, CLEAN_TIME_RESOLUTION_ADDR, 2);
	
	g_drying_time_max = DRYING_TIME_MAX_DEFAULT;
	temp_array[0] = (uint8_t)(DRYING_TIME_MAX_DEFAULT>>8);
	temp_array[1] = (uint8_t)(DRYING_TIME_MAX_DEFAULT);
	I2C_EE_BufferWrite(temp_array, DRYING_TIME_MAX_ADDR, 2);
	g_drying_time_resolution = DRYING_TIME_RESOLUTION_DEFAULT;
	temp_array[0] = (uint8_t)(DRYING_TIME_RESOLUTION_DEFAULT>>8);
	temp_array[1] = (uint8_t)(DRYING_TIME_RESOLUTION_DEFAULT);
	I2C_EE_BufferWrite(temp_array, DRYING_TIME_RESOLUTION_ADDR, 2);
	
	g_boost_time_max = BOOST_TIME_MAX_DEFAULT;
	temp_array[0] = (uint8_t)(BOOST_TIME_MAX_DEFAULT>>8);
	temp_array[1] = (uint8_t)(BOOST_TIME_MAX_DEFAULT);
	I2C_EE_BufferWrite(temp_array, BOOST_TIME_MAX_ADDR, 2);
	g_boost_time_resolution = BOOST_TIME_RESOLUTION_DEFAULT;
	temp_array[0] = (uint8_t)(BOOST_TIME_RESOLUTION_DEFAULT>>8);
	temp_array[1] = (uint8_t)(BOOST_TIME_RESOLUTION_DEFAULT);
	I2C_EE_BufferWrite(temp_array, BOOST_TIME_RESOLUTION_ADDR, 2);
	
	g_ala_enable = 1;
	I2C_EE_BufferWrite(&g_ala_enable, ALA_ENABLE_ADDR, 1);
	g_tun_enable =1;
	I2C_EE_BufferWrite(&g_tun_enable, TUN_ENABLE_ADDR, 1);
	
//	gizwitsSetMode(WIFI_RESET_MODE);
	
	//complete signal
	for(i=0; i<5; i++)
	{
		SetLedState(LED_POWER, LIGHT_ON);
		vTaskDelay(configTICK_RATE_HZ/10);
		SetLedState(LED_POWER, LIGHT_OFF);
		vTaskDelay(configTICK_RATE_HZ/10);
	}
	g_SystemStatus = MODE_NORMAL;
	printf("set system default completed.\r\n");
}

void TimerSleepCounter(void){
	if(g_light_enable == 0){
		g_light_enable = 1;
	}	
}

///*================================= TASKs  =======================================================================*/
void TaskPowerFlashing(void *parameter){
	
	while(1){
//		leds_control.led_power=!leds_control.led_power;
		SetLedFlashEnable(LED_POWER, ENABLE_FLASH4USER);
		vTaskDelay(configTICK_RATE_HZ/2);
	}
}

void TaskCleanFlashing(void *parameter){
	uint16_t i=0;
//	leds_control.led_clean=LED_ON;
	SetLedState(LED_CLEAN, LIGHT_ON);
	for(i=0; i<120; i++){
		SetLedState(LED_BOOST, LIGHT_ON);
		//BUZZER_ON();
		vTaskDelay(configTICK_RATE_HZ/5);//�ȿ���30s
		SetLedState(LED_BOOST, LIGHT_OFF);
		//BUZZER_OFF();
		vTaskDelay(configTICK_RATE_HZ/5);//�ȿ���30s
	}
	for(i=0; i<120; i++){
		SetLedState(LED_BOOST, LIGHT_ON);
		//BUZZER_ON();
		vTaskDelay(configTICK_RATE_HZ/5);//�ȿ���30s
		SetLedState(LED_BOOST, LIGHT_OFF);
		//BUZZER_OFF();
		vTaskDelay(configTICK_RATE_HZ/5);//�ȿ���30s
		vTaskDelay(configTICK_RATE_HZ*3);
	}
	SetLedState(LED_CLEAN, LIGHT_ON);
	while(1){	
		vTaskDelay(configTICK_RATE_HZ);		
	}
}



void TaskFaultGeneralFlashing(void *parameter){
	
	while(1){
		//BUZZER_ON();
		SetLedState(LED_ALL, LIGHT_ON);
		vTaskDelay(configTICK_RATE_HZ/2);
		//BUZZER_OFF();
		SetLedState(LED_ALL, LIGHT_OFF);
		vTaskDelay(configTICK_RATE_HZ/2);
	}
}


uint8_t g_clean_time[2] = {0, 0};
void TaskCountCleanTime(void *patameter){
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount ();
	while(1){
								/* if the system_stata is not normal, the implement the if(normal?) every second */
		vTaskDelay(configTICK_RATE_HZ);
		
		if(g_SystemStatus == MODE_NORMAL){
		
			I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
			/* 1���ж��Ƿ�������������cleanģʽ*/
			if(g_clean_time[CLEAN_TIME_HIGH]*256 + g_clean_time[CLEAN_TIME_LOW] >= g_clean_time_max){
				g_SystemStatus= MODE_CLEAN;
				continue;
			}
			
			/* 0��������ʱ */
			vTaskDelayUntil( &xLastWakeTime, configTICK_RATE_HZ*g_clean_time_resolution);	

			/* 2��cleanTime ʱ���ۼ� */
			I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
			if(g_clean_time[CLEAN_TIME_LOW]==0xff){
				g_clean_time[CLEAN_TIME_LOW] = 0;
				g_clean_time[CLEAN_TIME_HIGH] ++;
			}else{
				g_clean_time[CLEAN_TIME_LOW]++;
			}
			I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);
		}
		else {
					/* update the next time to start delay*/
			xLastWakeTime = xTaskGetTickCount ();
		}
		
	}//end while
}

void TaskHumidity(void *parameter){
	uint8_t state_calcu=0;
	while(1)
	{
		if(g_SystemStatus!=MODE_POWEROFF)
		{
			/* 1, get the data */
			GetTemperatureHumidity(&g_temperature, &g_humidity);
			/* 2, if module connected */
			if (g_temperature == (float)-40 && g_humidity == (float)0){
				if(state_calcu<10){
					state_calcu ++;
				}
				else {
					// flag disconnected
					g_malfunction.nodata_hdc_module = DISCONNECTED;
				}
				
			}else {
				if (state_calcu >0){
					state_calcu --;
				}else {
					// flag connected
					g_malfunction.nodata_hdc_module = CONNECTED;
				}
			}
			
			/* 3, if the humidity overlop */
			//if(g_humidity > HUMIDITY_MAX)
			   //g_SystemStatus=MODE_DRYING;
		}
		vTaskDelay(configTICK_RATE_HZ*5);//5s<B6><C1>h<B4><CE>
	}
}


void GetLightDiode(void){
	static uint8_t times=0;
	static uint16_t volt_array[5];
	float photo_diode_volt;
	
//	while(1){
		volt_array[times] = ADC_ConvertedValue[PhotoDiode_Subscript];
		if(++times>=5){
			times = 0;
			photo_diode_volt = (float)MiddleValueFilter(volt_array, 5)/4096*3.3;
			if(photo_diode_volt > 3) // > 3.0V
			{
				SetBrightness(BRIGHTNESS_HIGHEST);
			}
			else if(photo_diode_volt > 2) // 2.0V
			{
//				leds_control.led_brightness = BRIGHTNESS_HIGH;
				SetBrightness(BRIGHTNESS_HIGH);
			}
			else if(photo_diode_volt > 1.5) // 1.5V
			{
//				leds_control.led_brightness = BRIGHTNESS_MID;
				SetBrightness(BRIGHTNESS_MID);
			}
			else
			{
//				leds_control.led_brightness = BRIGHTNESS_LOW;
				SetBrightness(BRIGHTNESS_LOW);
			}
		}//end if
		vTaskDelay(configTICK_RATE_HZ/10);//ÿ100ms����һ��
//	}//end while	

}

void AdjBrightness(void) {
		
}

void TaskGetVoltDiodeAndAdj(void *parameter){
	static uint8_t times=0;
	static uint16_t volt_array[5];
	float photo_diode_volt, last_photo_diode_volt;
	uint8_t brightness;
	while(1){
		volt_array[times++] = ADC_ConvertedValue[PhotoDiode_Subscript];
		if(times>=3){
			times = 0;
			photo_diode_volt = (float)MiddleValueFilter(volt_array, 3)/4096*3.3;
			brightness = GetBrightness();
			if(photo_diode_volt > 3) // > 3.0V
			{
				if (brightness > BRIGHTNESS_HIGHEST) {
					SetBrightness(--brightness);
				} 
				else if (brightness < BRIGHTNESS_HIGHEST) {
					SetBrightness(++brightness);
				}
			}
			else if(photo_diode_volt > 2) // 2.0V
			{
				if (brightness > BRIGHTNESS_HIGH) {
					SetBrightness(--brightness);
				} 
				else if (brightness < BRIGHTNESS_HIGH) {
					SetBrightness(++brightness);
				}
			}
			else if(photo_diode_volt > 1.5) // 1.5V
			{
				if (brightness > BRIGHTNESS_MID) {
					SetBrightness(--brightness);
				} 
				else if (brightness < BRIGHTNESS_MID) {
					SetBrightness(++brightness);
				}
			}
			else
			{
				if (brightness > BRIGHTNESS_LOW) {
					SetBrightness(--brightness);
				} 
				else if (brightness < BRIGHTNESS_LOW) {
					SetBrightness(++brightness);
				}
			}
			
			last_photo_diode_volt = photo_diode_volt;

		}//end if
		
		vTaskDelay(configTICK_RATE_HZ/20);//ÿ100ms����һ��
	}//end while		
}



/*
	@ this buffer structure is for adc filter
*/
typedef struct {
	float * circular_buffer_array;
	uint8_t index;
	uint8_t length : 7;
	uint8_t full_flag : 1;
}circular_fbuffer;

uint8_t push_circular_fbuffer(circular_fbuffer *c, float data){
	c->circular_buffer_array[c->index] = data;
	c->index ++;
	if (c->index >= c->length) {
		c->index = 0;
		if (c->full_flag != 1) {
			c->full_flag = 1;
		}
	}
	
	return 1;
}

uint8_t reset_circular_fbuffer(circular_fbuffer *c){
	c->full_flag = 0;
	c->index = 0;
	
	return 1;
}
#define PERIODIC_SAMPLING_QUANTITY 20

float FilterAdcBuff(circular_fbuffer * c){
	float index_array[PERIODIC_SAMPLING_QUANTITY];
	float temp;
	float result;
	for (uint8_t i=0; i<c->length; i++) {
		index_array[i] = c->circular_buffer_array[i];
	}
					/* bubble sort for the index of data in buffer */
	for (uint8_t i=0; i<c->length-1; i++) {
		for (uint8_t j=0; j<c->length-i-1; j++) {
			if (index_array[j] > index_array[j+1]) {
				temp = index_array[j+1];
				index_array[j+1] = index_array[j];
				index_array[j] = temp;
			}
		}
	}
	
				/* now filter the data */
	result = index_array[10] 
					+ index_array[11]
					+ index_array[12]
					+ index_array[13]
					+ index_array[14]
					+ index_array[15];
	return (result / 6);

}
void TaskSecurity(void *parameter){
					/* init circular buffer for adc sampling */
	static float alarm_volt_buffer[PERIODIC_SAMPLING_QUANTITY];
	circular_fbuffer adc_circbuff;
	adc_circbuff.circular_buffer_array = alarm_volt_buffer;
	adc_circbuff.index = 0;
	adc_circbuff.length = PERIODIC_SAMPLING_QUANTITY;
	adc_circbuff.full_flag = 0;
	
	float ftemp;
	float fresult;

	while(1){
		
		if (1 == g_ala_enable){
			if(1 == IsHighVoltOn()){
				ftemp = (float)ADC_ConvertedValue[HighVolt_Alarm_Subscript]/4096*3.3;	
							/* push new data to buffer */
				push_circular_fbuffer(&adc_circbuff, ftemp);
				if (adc_circbuff.full_flag == 1) {
						  /* start filter and calculate */
					fresult = FilterAdcBuff(&adc_circbuff);
					if (GetFanMode() == STOP) {
						if(fresult > ALARM_VOLT_UPPER_LIMIT || fresult < ALARM_VOLT_LOWER_LIMIT_FAN_LOW){
							g_SystemStatus = MODE_FAULT;
							g_malfunction.alarm_highVolt = 1;
						}
						else {
							g_malfunction.alarm_highVolt = 0;
						}
					}
					else {
						if(fresult > ALARM_VOLT_UPPER_LIMIT || fresult < ALARM_VOLT_LOWER_LIMIT){
							g_SystemStatus = MODE_FAULT;
							g_malfunction.alarm_highVolt = 1;
						}
						else {
							g_malfunction.alarm_highVolt = 0;
						}
					}
					
				}
			}
			else {
				/* reset data */
				reset_circular_fbuffer(&adc_circbuff);
			}
		}
		
		vTaskDelay(configTICK_RATE_HZ/4);  /* sample every 250ms*/
		
		/* 1, alarm detect.*/
		//I2C_EE_BufferRead(&g_ala_enable, ALA_ENABLE_ADDR, 1);
//		{
//			if(IsHighVoltStable() == 1){
//				alarm_result=0;
//				if(1 == g_ala_enable)
//					alarm_result = GetVoltAlarm_N_Adj();
//				if(alarm_result!=0){
//					g_SystemStatus=MODE_FAULT;
//					g_malfunction.alarm_highVolt = 1;
//				}
//				else{
//					g_malfunction.alarm_highVolt = 0;
//				}
//			}
//		}
//		vTaskDelay(configTICK_RATE_HZ/20);
	}
}
void TaskAlarmDetect(void *parameter){
	uint8_t alarm_result;
	while(1){
		I2C_EE_BufferRead(&g_ala_enable, ALA_ENABLE_ADDR, 1);
		if(1 == g_ala_enable){
			if(IsHighVoltStable() == 1){
				alarm_result = GetVoltAlarm_N_Adj();
				if(alarm_result!=0){
					g_SystemStatus=MODE_FAULT;
				}
			}
		}
		vTaskDelay(configTICK_RATE_HZ/50);
	}
}

void TaskTungstenDetect(void *parameter){
	uint8_t detect_times=0;
	uint8_t fault_times=0;
	uint8_t tungsten_result;
	while(1){
		I2C_EE_BufferRead(&g_tun_enable, TUN_ENABLE_ADDR, 1);
		if(1 == g_tun_enable){
			if(IsHighVoltStable() == 1){
				tungsten_result = GetVoltTungsten_N_Adj();
				if(tungsten_result != 0){
					fault_times++;
				}
				if(detect_times++>=40){
					if(fault_times>=30){
						g_SystemStatus=MODE_FAULT;
					}
					detect_times=0;
					fault_times=0;
				}
			}
		}	
		vTaskDelay(configTICK_RATE_HZ/20);
	}// end while
}

void TaskSecurityDetect(void *parameter){
	uint8_t detect_times=0;
	uint8_t fault_times=0;
	while(1){
		if(g_SystemStatus == MODE_NORMAL){
			g_fault_code = GetVoltTungsten_N_Adj();
			g_fault_code |= GetVoltAlarm_N_Adj();
			if(g_fault_code!=0) {
				fault_times++;
				g_fault_code=0;
			}
			if(detect_times++>=100){
				if(fault_times>=80){
					g_SystemStatus=MODE_FAULT;
				}
				detect_times=0;
				fault_times=0;
			}
		}	
		vTaskDelay(configTICK_RATE_HZ/50);
	}
}



uint8_t g_power_onoff_action = 0;
uint8_t g_fan_change_action = 0;
uint8_t g_ai_action = 0;
uint8_t g_pair_action = 0;
const uint8_t g_no_ch2o_module = 0;
void TaskScanKeys(void *parameter){
	static uint16_t count_power = 0;
	static uint16_t count_mode = 0;
	static uint16_t count_boost = 0;
	KeyType key_power_state;
	KeyType key_mode_state;
	KeyType	key_boost_state;
	EventBits_t uxBits;
	/* �����¼� */
	key_event = xEventGroupCreate();
	
	while(1){		
//		rt_thread_delay(RT_TICK_PER_SECOND/50);/* ÿ20ms���һ��*/	
		vTaskDelay(configTICK_RATE_HZ*20/1000);
		
		
		key_power_state = key_nscan(key_power_GPIO_Port, key_power_Pin, &count_power, KEY_5S_TIME);
		key_mode_state = key_nscan(key_mode_GPIO_Port, key_mode_Pin, &count_mode, KEY_2S_TIME);
		key_boost_state = key_nscan(key_boost_GPIO_Port, key_boost_Pin, &count_boost, KEY_2S_TIME);
		
		/* ͭ�� */
		if (g_lock != 1) {
			if(key_power_state == KEY_SHORT_PRESS){
				xEventGroupSetBits(key_event, KEY_POWER_SHORT_BIT);
			}else if(key_power_state == KEY_2S_PRESS){
				xEventGroupSetBits(key_event, KEY_POWER_2S_BIT);
			}else if(key_power_state == KEY_10S_PRESS){
				xEventGroupSetBits(key_event, KEY_POWER_10S_BIT);
			}else if(key_power_state == KEY_LONG_PRESS){
				xEventGroupSetBits(key_event, KEY_POWER_LONG_BIT);
			}
			if(key_boost_state == KEY_SHORT_PRESS){
				xEventGroupSetBits(key_event, KEY_BOOST_SHORT_BIT);
			}else if(key_boost_state == KEY_2S_PRESS){
				xEventGroupSetBits(key_event, KEY_BOOST_2S_BIT);
			}else if(key_boost_state == KEY_10S_PRESS){
				xEventGroupSetBits(key_event, KEY_BOOST_10S_BIT);
			}else if(key_boost_state == KEY_LONG_PRESS){
				xEventGroupSetBits(key_event, KEY_BOOST_LONG_BIT);
			}
			if(key_mode_state == KEY_SHORT_PRESS){
				xEventGroupSetBits(key_event, KEY_MODE_SHORT_BIT);
			}else if(key_mode_state == KEY_2S_PRESS){
				xEventGroupSetBits(key_event, KEY_MODE_2S_BIT);
			}else if(key_mode_state == KEY_10S_PRESS){
				xEventGroupSetBits(key_event, KEY_MODE_10S_BIT);
			}else if(key_mode_state == KEY_LONG_PRESS){
				xEventGroupSetBits(key_event, KEY_MODE_LONG_BIT);
			}
		}
		
		
		
		uxBits = xEventGroupWaitBits(
					key_event,    // The event group being tested.
					KEY_POWER_SHORT_BIT | KEY_POWER_2S_BIT | KEY_POWER_10S_BIT | KEY_POWER_LONG_BIT | 
					KEY_BOOST_SHORT_BIT | KEY_BOOST_2S_BIT | KEY_BOOST_10S_BIT | KEY_BOOST_LONG_BIT | 
					KEY_MODE_SHORT_BIT  | KEY_MODE_2S_BIT  | KEY_MODE_10S_BIT  | KEY_MODE_LONG_BIT,  // The  bits within the event group to wait for.
					pdTRUE,         // should be cleared before returning.
					pdFALSE,        // Don't wait for both bits, either bit will do.
					0 ); // Wait a maximum of 100ms for either bit to be set.
		
		if(((uxBits & KEY_POWER_SHORT_BIT ) == KEY_POWER_SHORT_BIT) || (1 == g_power_onoff_action)){
			g_power_onoff_action = 0;
			if(g_SystemStatus == MODE_POWEROFF){
				g_SystemStatus = MODE_NORMAL;
			}else {
				g_SystemStatus = MODE_POWEROFF;
			}
		}
		else if((uxBits & KEY_POWER_LONG_BIT ) == KEY_POWER_LONG_BIT){
			SetSystemDefault();
		}
		else if(((uxBits & KEY_BOOST_SHORT_BIT ) == KEY_BOOST_SHORT_BIT) || (1 == g_ai_action))
		{
			/* into mode AI */
//			g_ai_action = 0;
			//g_fan_mode = AI;
			
		}
		else if((uxBits & KEY_BOOST_LONG_BIT ) == KEY_BOOST_LONG_BIT){
			if(g_SystemStatus == MODE_CLEAN){
				/* ������ʱ���ۻ� */
				g_clean_time[CLEAN_TIME_HIGH] = 0;
				g_clean_time[CLEAN_TIME_LOW] = 0;
				I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);

				g_SystemStatus=MODE_NORMAL;
			}
		}
		else if( (( uxBits & KEY_MODE_SHORT_BIT ) == KEY_MODE_SHORT_BIT) || (1 == g_fan_change_action) ){
			g_fan_change_action = 0;
			AdjFanRecurrently();
		}
		else if( (( uxBits & KEY_MODE_LONG_BIT ) == KEY_MODE_LONG_BIT) || (1 == g_pair_action) ){
			/* pair wifi */
		}
		else {}
			
	}//end while
}

eTaskState ee;
void TaskChangeSystemOutput(void *parameter){
	static MODE last_systemStatus=MODE_FAULT;
	MODE now_systemStatus;

	while(1){
		/* 1,ȡ����ϵͳ״̬��ֵ */
		now_systemStatus = g_SystemStatus;
			
		/* 2, ����ϵͳ״̬����״̬��ʾ */
		if(last_systemStatus != now_systemStatus){/* ϵͳ״̬�л������ */		
			if (now_systemStatus == MODE_NORMAL || now_systemStatus == MODE_CLEAN) {
				TurnOnFan();
			}
			else {
				TurnOffFan();
			}
			
			switch (now_systemStatus)
            {
            	case MODE_NORMAL:
					printf("into mode_normal.\r\n");
					SetLedState(LED_POWER, LIGHT_ON);
					SetLedState(LED_BOOST, LIGHT_OFF);
					SetLedState(LED_DRYING, LIGHT_OFF);
					SetLedState(LED_CLEAN, LIGHT_OFF);
					
            		break;
            	case MODE_POWEROFF:
					printf("into mode_poweroff.\r\n");
					SetLedState(LED_ALL, LIGHT_OFF);
				
            		break;
				case MODE_CLEAN:
					printf("into mode_clean.\r\n");
												//Water led flashing + buzzer alarm (more fiecre at initial&stop if long idle)
					SetLedState(LED_POWER, LIGHT_ON);
					SetLedState(LED_BOOST, LIGHT_OFF);
					SetLedState(LED_DRYING, LIGHT_OFF);
					SetLedState(LED_CLEAN, LIGHT_ON);
					if(f_clean_created == 0){
						f_clean_created = 1;
						xTaskCreate(TaskCleanFlashing, "clean flashing", 32, NULL, 1, &HandleCleanFlashing);
					}
					break;
				case MODE_FAULT:
					printf("into mode_fault.\r\n");
					SetLedState(LED_POWER, LIGHT_ON);
					if(f_fault_created==0){
						f_fault_created=1;
						xTaskCreate(TaskFaultGeneralFlashing, "fault flashing", 32, NULL, 1, &HandleFaultGeneralFlashing);	
					}
					break;
				case MODE_TEST:
					break;
            	default:
            		break;
            }
		}

				/* 4, ɾ������*/
		if(g_SystemStatus != MODE_CLEAN){
			if(f_clean_created == 1){
				f_clean_created = 0;
				vTaskDelete(HandleCleanFlashing);
							/* ȷ�����𣬷��������� */
				BUZZER_OFF();	
				SetLedState(LED_BOOST, LIGHT_OFF);
			}
		}
		if(g_SystemStatus != MODE_FAULT){
			if(f_fault_created == 1){
				f_fault_created = 0;
				vTaskDelete(HandleFaultGeneralFlashing);
				BUZZER_OFF();
			}
		}
		
		
				/* 5������ϵͳ״̬�ͷ���״ֵ̬ */
		last_systemStatus = now_systemStatus;	
				/* 8, watch dog */
		#ifdef WATCH_DOG
		watchdogFeed();	
		#endif	
								/* ÿ20ms���һ��*/	
		vTaskDelay(configTICK_RATE_HZ/50);
	}//end while
}


