/**
  ******************************************************************************
  * @file    
  * @author  
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
 
  ******************************************************************************
  */  
  
 /*
	Version AP360S_FreeRTOS_V2.2  2017-5-25
	
	1,add TIM2 initialization & interrupt handle"TIM2_IRQHandler".
	2,move lightness adj function from task "TaskLedsBrightness" to "TIM2_IRQHandler".
	3,delete function task "TaskLedsBrightness".
	4,add 5 commands to set system state.
	5,add shut down fan operation, when entering the fault mode.
	6,Set the led flashing cyscle to 200Hz. 
	7,Enable watch dog.
 
	Version AP360S_FreeRTOS_V2.2.1  2017-5-25
	1��change boost time from 1200s(20min) to 5400s(90min) for certification&to do the experiment.
	
	Version AP360S_FreeRTOS_V2.3  2017-5-25
	1��set the low speed pwm of fan from 17% to 20%. 
	2��implement some parameter config, such as boost/clean/drying mode duration and boost/clean/drying mode resolution.
	
	Version AP360S_FreeRTOS_V2.4  2017-5-31
	1��1 second after enable high voltage output, start safety mornitoring, which include alarm port and tungstens detection.
	2����˿��ⷽ��Ϊ��ÿ�����40�Σ�����30�쳣�򱨾���
	3, alarm���ⷽ��Ϊ��һ���쳣���ϱ�����
	
	Version AP360S_FressRTOS_V2.5   2017-6-1
	1, add power on signal.
	2, change fan mode disp, include boost mode.
	3, when turbo mode  conuting down to 0, aotumatically jump to low speed.
	4, enable configUSE_TICKLESS_IDLE into the low power mode. The total supply current is reduced by about 20mA.
	
	Version AP360S_FressRTOS_V2.6   2017-6-7
	1, After power on, into MODE_POWEROFF
	2, Fixed that all led flashing together once at the power on.
	
	Version AP360S_FressRTOS_V3.1   2017-6-10
	1, Use short press on/off machine, replace the 3s long press.
	2, Replace heap_2.c with heap_4.c 
	
	Version AP360S_FressRTOS_V3.2   2017-6-28
	1, change humidity_max from 95% to 97%.
	
	Version AP360S_FressRTOS_V3.3
	2017-7-4
	1, change humidity_max from 97% to 99%.
	2, add the function to show software version while machine power on.
	
	Version AP360S_FressRTOS_V3.4
	2017-7-6
	1, update some function(eeprom data, task_security) to synchronize with AP360C
	2, fix the led_power interfere the power on signal.
	
	Version AP360S_FressRTOS_V3.5
	2017-7-18
	1, change the alarm range from 0.285-0.902 to 0.185-1.002.
	
	Version AP360S_FressRTOS_V3.6
	2017-7-21
	1, change the high_volt in different fan speed.(16.5KV +0.5/-1 KV fro 1,2,3,T; 14 -1/+1kv for 0)
	
	Version AP360S_FressRTOS_V3.7
	2017-8-11
	1, change the high_volt stable duration from 1s to 2s
	2, delete the tungsten detect function.
	3, modify the implement of key detection.
	
	Version 3.8
	2017-8-22
	1, modify the alarm detection, set the low limit from 1.8 to 1.0 when system in fan_stop_mode.
	2, modify the 14KV_REF_PWM from 86 to 83
	
	Version 3.9
	2017-9-6
	1, fixed the clean function problem.
	
	Version 4.1
	2017-11-9
	1, changed the clean mode disp;
	2, modified the func "TaskCountCleanTime".
	
	Version 4.3
	2017-11-15
	1, all new
	2, chagne the low and mid fan_mode voltage
	3, adapted fan pwm smoothly.
	4, set clean_time bigger than max_clean_time when check the SW
	5, the machine still can clean air when it enter the clean_mode.
	
	Version 4.3.2
	1, 	changed the two parameter below
		#define FAN_PWM_LOW    32
		#define FAN_PWM_MID    60
		
	Version 4.3.3
	1,  disabel press ai bottom and press 3s fan_bottom
	2,  after display sw, it turn to mode_mormal
	3,  turn off the clean_led after get rid of the clean_mode
	4,  change the positon of disp_sw hehind the power_on_signal
	5,  change the poweron signal direction form left to right
	6,  �޸�����������ͻ���ź�����
	
	Version 4.4
	2017-12-14
	1, make buzzer silent when ap into cleanning mode.
	2, modified the TaskCountCleanTime as same as ap360c
	
	version 4.9		Author:LSM		Time:2019-01-23
	1. change CLEAN_TIME_MAX_DEFAULT to 2016 ,extending the wait_time_to_clean from 2 weeks to 3 months.
 */ 
  
  

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include "serial.h"
#include "BSP_AP360_GPIO.H"
#include "BSP_TIMER.h" 
#include "BSP_EEPROM.h"	
#include "BSP_SysTick.h"
#include "BSP_RCC.h"
#include "BSP_UART.h"
//#include "BSP_HDC1080.h"
#include "BSP_ADC.h"
#include "sw_iic.h"
#include "filter.h"
#include "app_ap36xx.h"
#include "cli_zhu.h"
#include "api_led.h"
#include "api_fan.h"

#include "FreeRTOS.h"
#include "task.h"


/* THE software version */
const uint8_t software_version[2] = {5, 1};

void PowerOnSignal(void);
void ResumeData(void);
void DelayTest(void);
void disp_swv(void);

void delay_ms(unsigned int ms){
	unsigned i=0;
	while(ms--){
		i=8000;
		while(i--);
	}
}


int main(void)
{
	/*-------initialization-------------------------------*/
//	HSE_SetSysClock(RCC_PLLMul_9);
////	SysTick_Init();	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	GpioInit();
	ADVANCE_TIM_Init();//TIM1
	GENERAL_TIM_Init();//TIM4  PWM���
	TIM2_Init();
	I2C_EE_Init();
	SW_I2C_Config();
	ADCx_Init();
	USART_Config();
	
	InitAllLeds();
	InitFan();
	
	delay_ms(500);//��1080Ԥ��ʱ��
	InitHDC1080_sw_iic();
	
/* 3, data resume, get these settable parameter from eeprom*/
	ResumeData();
	
	PowerOnSignal();
	printf("system started.\r\n");
	/* show the version of the software */
	disp_swv();
	
  g_SystemStatus = MODE_NORMAL;//����������
	
	#ifdef WATCH_DOG
	watchdogInit(5); /* watch dog ����10�� */
	#endif
	
	xTaskCreate(vTaskCmdAnalyze, "cli_zhu", 256, NULL, 1, &xCmdAnalyzeHandle);

	xTaskCreate(TaskSecurity, "security", 80, NULL, 1, NULL);
	xTaskCreate(TaskScanKeys, "key_scan", 128, NULL, 4, NULL);
	xTaskCreate(TaskGetVoltDiodeAndAdj, "Detect diode", 128, NULL, 1, NULL);
	xTaskCreate(TaskChangeSystemOutput, "stauts change", 256, NULL, 2, NULL);
	xTaskCreate(TaskHumidity, "humidity", 256, NULL, 1, NULL);
	xTaskCreate(TaskCountCleanTime, "clean time", 128, NULL, 1, NULL);
	
	vTaskStartScheduler();
	while(1);
	
}


void ResumeData(void){
	uint8_t temp_array[2];
	
	
	I2C_EE_BufferRead(g_clean_time, CLEAN_TIME_ADDR, 2);
	I2C_EE_BufferRead(temp_array, CLEAN_TIME_MAX_ADDR, 2);
	g_clean_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, CLEAN_TIME_RESOLUTION_ADDR, 2);
	g_clean_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, BOOST_TIME_MAX_ADDR, 2);
	g_boost_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, BOOST_TIME_RESOLUTION_ADDR, 2);
	g_boost_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, DRYING_TIME_MAX_ADDR, 2);
	g_drying_time_max = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	I2C_EE_BufferRead(temp_array, DRYING_TIME_RESOLUTION_ADDR, 2);
	g_drying_time_resolution = (uint16_t)temp_array[0]*256+(uint16_t)temp_array[1];
	
	I2C_EE_BufferRead(&g_ala_enable, ALA_ENABLE_ADDR, 1);
	I2C_EE_BufferRead(&g_tun_enable, TUN_ENABLE_ADDR, 1);
}

/*
	using led to show the software version
	
*/
void disp_swv(void){
	uint8_t version;
	uint8_t subversion;
	uint8_t i;
	version = software_version[0];
	subversion = software_version[1];
	
	if (0==key_state(key_mode_GPIO_Port, key_mode_Pin)){
		delay_ms(20);
		SetLedState(LED_POWER, LIGHT_ON);
		while(0==key_state(key_mode_GPIO_Port, key_mode_Pin));
//		SetLedColor(LED_POWER, BLUE);
//		SetLedState(LED_POWER, LIGHT_ON);
//		SetLedState(LED_BOOST, LIGHT_ON);
//		SetLedColor(LED_BOOST, RED);
		for (i=0; i<version; i++){
			SetLedState(LED_CLEAN, LIGHT_ON);
			delay_ms(100);
			SetLedState(LED_CLEAN, LIGHT_OFF);
			delay_ms(500);
		}
		
		SetLedColor(LED_BOOST, ORANGE);
		
		for (i=0; i<subversion; i++){
			SetLedState(LED_LOW, LIGHT_ON);
			delay_ms(100);
			SetLedState(LED_LOW, LIGHT_OFF);
			delay_ms(500);
		}	
					/* �޸����ʱ��  */
		g_clean_time[CLEAN_TIME_HIGH] = (CLEAN_TIME_MAX_DEFAULT + 1) / 256;
		g_clean_time[CLEAN_TIME_LOW] = (CLEAN_TIME_MAX_DEFAULT + 1) % 256;
		I2C_EE_BufferWrite(g_clean_time, CLEAN_TIME_ADDR, 2);
		
		g_SystemStatus = MODE_NORMAL;
	} // end if
}
