# AP360S
<<<<<<< HEAD
Version AP360S_FreeRTOS_V2.2  2017-5-25
	1,add TIM2 initialization & interrupt handle"TIM2_IRQHandler".
	2,move lightness adj function from task "TaskLedsBrightness" to "TIM2_IRQHandler".
	3,delete function task "TaskLedsBrightness".
	4,add 5 commands to set system state.
	5,add shut down fan operation, when entering the fault mode.
	6,Set the led flashing cyscle to 200Hz. 
	7,Enable watch dog.
 
Version AP360S_FreeRTOS_V2.2.1  2017-5-25
	1£¬change boost time from 1200s(20min) to 5400s(90min) for certification&to do the experiment.
	
Version AP360S_FreeRTOS_V2.3  2017-5-25
	1£¬set the low speed pwm of fan from 17% to 20%. 
	2£¬implement some parameter config, such as boost/clean/drying mode duration and boost/clean/drying mode resolution.
	
Version AP360S_FreeRTOS_V2.4  2017-5-31
	1£¬1 second after enable high voltage output, start safety mornitoring, which include alarm port and tungstens detection.
	2£¬ÎÙË¿¼ì²â·½·¨Îª£¬Ã¿Á½Ãë²â40´Î£¬³¬¹ý30Òì³£Ôò±¨¾¯¡£
	3, alarmµã¼ì²â·½·¨Îª£¬Ò»µ©Òì³£ÂíÉÏ±¨¾¯¡£
	
Version AP360S_FressRTOS_V2.5   2017-6-1
	1, add power on signal.
	2, change fan mode disp, include boost mode.
	3, when turbo mode  conuting down to 0, aotumatically jump to low speed.
	4, enable configUSE_TICKLESS_IDLE into the low power mode. The total supply current is reduced by about 20mA.
	
Version AP360S_FressRTOS_V2.6   2017-6-7
	1, After power on, into MODE_POWEROFF
	2, Fixed that all led flashing together once at the power on.
	
Version AP360S_FressRTOS_V3.1   2017-6-10
	1, Use short press on/off machine, replace the 3s long press.
	2, Replace heap_2.c with heap_4.c 
	
Version AP360S_FressRTOS_V3.2   2017-6-28
	1, change humidity_max from 95% to 97%.
	
Version AP360S_FressRTOS_V3.3
	2017-7-4
	1, change humidity_max from 97% to 99%.
	2, add the function to show software version while machine power on.
	
Version AP360S_FressRTOS_V3.4
	2017-7-6
	1, update some function(eeprom data, task_security) to synchronize with AP360C
	2, fix the led_power interfere the power on signal.
	
Version AP360S_FressRTOS_V3.5
	2017-7-18
	1, change the alarm range from 0.285-0.902 to 0.185-1.002.
	
Version AP360S_FressRTOS_V3.6
	2017-7-21
	1, change the high_volt in different fan speed.(16.5KV +0.5/-1 KV fro 1,2,3,T; 14 -1/+1kv for 0)
	
Version AP360S_FressRTOS_V3.7
	2017-8-11
	1, change the high_volt stable duration from 1s to 2s
	2, delete the tungsten detect function.
	3, modify the implement of key detection.
	
Version 3.8
	2017-8-22
	1, modify the alarm detection, set the low limit from 1.8 to 1.0 when system in fan_stop_mode.
	2, modify the 14KV_REF_PWM from 86 to 83
	
Version 3.9
	2017-9-6
	1, fixed the clean function problem.
=======
repo for ap360s
>>>>>>> 5569381e5486e5c5d235eb963bc44d231a46c9ee
