#ifndef __BSP_CH2O_N_PM25_H
#define	__BSP_CH2O_N_PM25_H

#include "stm32f10x.h"
#include "sw_fifo.h"
/*
		��������ģ���Ӧ�Ĵ��ںš�FIFO���Լ�������������
*/
#define UART_CH2O USART3
#define UART_PM  USART3
#define CH2O_RX_FIFO uart3_rx_fifo
#define PM_RX_FIFO uart3_rx_fifo

#define LENGTH_CH2O_DATA 5

#define SIZE_COMMAND_CH2O 5
#define SIZE_COMMAND_PM25 19
#define NUM_CH20_RECIVED_DATA  9
#define NUM_PM25_RECIVED_DATA  10

extern const uint8_t command_get_CH2O[SIZE_COMMAND_CH2O];
extern const uint8_t command_get_PM25[SIZE_COMMAND_PM25];

/*
  С���ṹ�壬��value/divisor �ɵõ�С��ֵ
*/
typedef struct{
	uint16_t value;
	uint8_t divisor;
}UnsignedDecimal;

typedef struct{
	uint16_t *sensor_data_array;
	uint8_t divisor;
	uint8_t sensor_array_index;  // ָ���������������ݵ���һ��
	uint8_t data_length;
	uint8_t array_full_flag;
	
}SENSOR_DataHandle;

extern SENSOR_DataHandle CH2O_MG_DataHandle;
extern SENSOR_DataHandle CH2O_PPM_DataHandle;
extern SENSOR_DataHandle PM25_DataHandle;
extern SENSOR_DataHandle PM10_DataHandle;

uint8_t SendCommand(USART_TypeDef *uart, uint8_t *command_addess, uint8_t command_length);
void PushToSensorArray(SENSOR_DataHandle * sensor_data_handle, uint16_t data);
void GetCH2O_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo);
void GetPM25_V2(USART_TypeDef *huart,sw_fifo_typedef *uart_rx_fifo);

#endif /* __UART_H */


