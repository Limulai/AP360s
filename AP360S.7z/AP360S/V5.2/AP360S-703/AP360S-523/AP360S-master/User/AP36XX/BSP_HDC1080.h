/*
Description: �˽ӿڳ�������STM32 ��׼��֮��

*/

#ifndef __BSP_HDC1080_H
#define	__BSP_HDC1080_H


#include "stm32f10x.h"

#define  HDC1080_I2Cx  I2C1

#define ADDRESS_HDC1080 0X80
#define ADDRESS_TEMPERATURE 0X00
#define ADDRESS_HUMIDITY 0X01
#define ADDRESS_CONFIGURATION 0X02

/*�ȴ���ʱʱ��*/
#define HDC1080_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define HDC1080_LONG_TIMEOUT         ((uint32_t)(10 * I2CT_FLAG_TIMEOUT))

uint8_t InitHDC1080(I2C_TypeDef * IICx);
uint8_t ReadHDC1080(I2C_TypeDef * IICx, uint16_t *temperature, uint16_t *humidity);

#endif /* __BSP_HDC1080_H */
