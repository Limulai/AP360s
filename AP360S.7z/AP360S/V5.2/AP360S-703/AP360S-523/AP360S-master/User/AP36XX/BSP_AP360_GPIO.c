#include "BSP_AP360_GPIO.H"



/*======================================================================
======================================================================*/	
//                    GPIO_BSP  KEYs&LEDs	

void GpioInit(void)//GPIO��ʼ�����̣����ýṹ��->������Ӧ��ʱ��(���������衢����)->ʵ�����ṹ�����->���ú�����ʵ����
	{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	/***********************BUZZER *****************************/
	GPIO_InitStructure.GPIO_Pin = buzzer_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(buzzer_GPIO_Port, &GPIO_InitStructure);
	
	/***********************high_volt_on/off config*****************************/
	GPIO_InitStructure.GPIO_Pin = high_volt_on_off_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(high_volt_on_off_GPIO_Port, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = high_volt_ref_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(high_volt_ref_GPIO_Port, &GPIO_InitStructure);
	
	/***********************LED config*****************************/
	GPIO_SetBits(led_power_GPIO_Port_green, led_power_Pin_green);   
	GPIO_SetBits(led_power_GPIO_Port_blue, led_power_Pin_blue); 
	GPIO_SetBits(led_boost_GPIO_Port_green, led_boost_Pin_green);	
	GPIO_SetBits(led_boost_GPIO_Port_red, led_boost_Pin_red);		
	GPIO_SetBits(led_high_GPIO_Port, led_high_Pin);														
	GPIO_SetBits(led_mid_GPIO_Port, led_mid_Pin);
	GPIO_SetBits(led_low_GPIO_Port, led_low_Pin);
	GPIO_SetBits(led_drying_GPIO_Port, led_drying_Pin);
	GPIO_SetBits(led_clean_GPIO_Port, led_clean_Pin);
	
	GPIO_InitStructure.GPIO_Pin = led_power_Pin_green;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_power_GPIO_Port_green, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_power_Pin_blue;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_power_GPIO_Port_blue, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_boost_Pin_green;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_boost_GPIO_Port_green, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_boost_Pin_red;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_boost_GPIO_Port_red, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_high_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_high_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_mid_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_mid_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_low_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_low_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_drying_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_drying_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = led_clean_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(led_clean_GPIO_Port, &GPIO_InitStructure);

	
	
	/***********************KEY config**************************/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	AFIO->MAPR &= ~(0x3<<24);
	AFIO->MAPR |= (0x2<<24);
	//GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = key_power_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(key_power_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = key_boost_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(key_boost_GPIO_Port, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = key_mode_Pin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(key_mode_GPIO_Port, &GPIO_InitStructure);
}









