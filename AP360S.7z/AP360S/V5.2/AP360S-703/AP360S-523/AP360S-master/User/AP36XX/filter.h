#ifndef __FILTER_H__
#define __FILTER_H__
#include <stm32f10x.h>

uint16_t MiddleValueFilter(uint16_t *array, uint8_t length_array);
uint16_t AmplitudeLimiterFilter(uint16_t new_val, uint16_t default_val, uint16_t max_val, uint16_t min_val);
uint16_t ArithmeticalAverageFilter(uint16_t *array, uint8_t length_array);

/*Designed for zitzapper*/
uint8_t BuzzerFilter(uint8_t *array, uint8_t array_num, uint8_t max_val, uint8_t min_val);
#endif

