#ifndef __BSP_AP360_GPIO_H__
#define __BSP_AP360_GPIO_H__

#include <stm32f10x.h>

/* IO�궨�� */
#define adc1_0_gm_Pin 							GPIO_Pin_0
#define adc1_0_gm_GPIO_Port 				GPIOA
#define adc1_1_ws_Pin							  GPIO_Pin_1
#define adc1_1_ws_GPIO_Port 				GPIOA
#define adc2_4_high_volt_Pin 				GPIO_Pin_4
#define adc2_4_high_volt_GPIO_Port 	GPIOA
#define pwm_1_Pin 									GPIO_Pin_6
#define pwm_1_GPIO_Port 						GPIOA

#define boot1_Pin 									GPIO_Pin_2
#define boot1_GPIO_Port 						GPIOB


#define led_power_Pin_green                GPIO_Pin_13
#define led_power_GPIO_Port_green          GPIOC
#define led_power_Pin_blue                GPIO_Pin_6
#define led_power_GPIO_Port_blue          GPIOA
#define led_boost_Pin_green                GPIO_Pin_0
#define led_boost_GPIO_Port_green          GPIOB
#define led_boost_Pin_red                GPIO_Pin_7
#define led_boost_GPIO_Port_red          GPIOA
#define led_high_Pin								 GPIO_Pin_1
#define led_high_GPIO_Port           GPIOB
#define led_mid_Pin									 GPIO_Pin_0
#define led_mid_GPIO_Port						 GPIOA
#define led_low_Pin                  GPIO_Pin_12
#define led_low_GPIO_Port            GPIOB
#define led_clean_Pin								 GPIO_Pin_14
#define led_clean_GPIO_Port					 GPIOB
#define led_drying_Pin							 GPIO_Pin_13
#define led_drying_GPIO_Port				 GPIOB


#define key_power_Pin								 GPIO_Pin_5
#define key_power_GPIO_Port					 GPIOB
#define key_mode_Pin								 GPIO_Pin_3
#define key_mode_GPIO_Port					 GPIOB
#define key_boost_Pin								 GPIO_Pin_4
#define key_boost_GPIO_Port					 GPIOB
#define high_volt_on_off_Pin         GPIO_Pin_8
#define high_volt_on_off_GPIO_Port   GPIOA
#define high_volt_ref_Pin      		   GPIO_Pin_0
#define high_volt_ref_GPIO_Port 	   GPIOA
#define buzzer_Pin  								 GPIO_Pin_5
#define buzzer_GPIO_Port   					 GPIOA


/* ֱ�Ӳ����Ĵ����ķ�������IO */
#define	digitalHi(p,i)		 {p->BSRR=i;}	 //���Ϊ�ߵ�ƽ		
#define digitalLo(p,i)		 {p->BRR=i;}	 //����͵�ƽ
#define digitalToggle(p,i) {p->ODR ^=i;} //�����ת״̬


/* �������IO�ĺ� */
#define BUZZER_ON()				digitalHi(buzzer_GPIO_Port,buzzer_Pin  )
#define BUZZER_OFF()			digitalLo(buzzer_GPIO_Port,buzzer_Pin  )


//#define LED_POWER_TOGGLE()		   digitalToggle(led_power_GPIO_Port,led_power_Pin)
#define LED_POWER_OFF()	   		   digitalHi(led_power_GPIO_Port_green,led_power_Pin_green); digitalHi(led_power_GPIO_Port_blue,led_power_Pin_blue)
#define LED_POWER_GREEN()		   digitalLo(led_power_GPIO_Port_green,led_power_Pin_green); digitalHi(led_power_GPIO_Port_blue,led_power_Pin_blue)
#define LED_POWER_BLUE()		   digitalLo(led_power_GPIO_Port_blue,led_power_Pin_blue); digitalHi(led_power_GPIO_Port_green,led_power_Pin_green)

//#define LED_BOOST_TOGGLE()		   digitalToggle(led_boost_GPIO_Port,led_boost_Pin)
#define LED_BOOST_OFF()		       digitalHi(led_boost_GPIO_Port_green,led_boost_Pin_green); digitalHi(led_boost_GPIO_Port_red,led_boost_Pin_red)
#define LED_BOOST_GREEN()		   digitalLo(led_boost_GPIO_Port_green,led_boost_Pin_green); digitalHi(led_boost_GPIO_Port_red,led_boost_Pin_red)
#define LED_BOOST_RED()			   digitalHi(led_boost_GPIO_Port_green,led_boost_Pin_green); digitalLo(led_boost_GPIO_Port_red,led_boost_Pin_red)
#define LED_BOOST_ORANGE()		   digitalLo(led_boost_GPIO_Port_green,led_boost_Pin_green); digitalLo(led_boost_GPIO_Port_red,led_boost_Pin_red)

#define LED_HIGH_TOGGLE()		 digitalToggle(led_high_GPIO_Port,led_high_Pin)
#define LED_HIGH_OFF()		   digitalHi(led_high_GPIO_Port,led_high_Pin)
#define LED_HIGH_GREEN()			   digitalLo(led_high_GPIO_Port,led_high_Pin)

#define LED_MID_TOGGLE()		 digitalToggle(led_mid_GPIO_Port,led_mid_Pin)
#define LED_MID_OFF()		   digitalHi(led_mid_GPIO_Port,led_mid_Pin)
#define LED_MID_GREEN()			   digitalLo(led_mid_GPIO_Port,led_mid_Pin)

#define LED_LOW_TOGGLE()		 digitalToggle(led_low_GPIO_Port,led_low_Pin)
#define LED_LOW_OFF()		   digitalHi(led_low_GPIO_Port,led_low_Pin)
#define LED_LOW_GREEN()			   digitalLo(led_low_GPIO_Port,led_low_Pin)

#define LED_DRYING_TOGGLE()		 digitalToggle(led_drying_GPIO_Port,led_drying_Pin)
#define LED_DRYING_OFF()		   digitalHi(led_drying_GPIO_Port,led_drying_Pin)
#define LED_DRYING_GREEN()			   digitalLo(led_drying_GPIO_Port,led_drying_Pin)

#define LED_CLEAN_TOGGLE()		 digitalToggle(led_clean_GPIO_Port,led_clean_Pin)
#define LED_CLEAN_OFF()		   digitalHi(led_clean_GPIO_Port,led_clean_Pin)
#define LED_CLEAN_GREEN()			   digitalLo(led_clean_GPIO_Port,led_clean_Pin)

void GpioInit(void);

#endif


